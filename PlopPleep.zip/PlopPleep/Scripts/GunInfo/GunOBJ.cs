using Godot;
using System;

namespace GunOBJ{
public class GunOBJ : Node
{
    
    public string name {get; set;}
    public string desc {get; set;}
    public string file {get; set;}
    public string caliber{get;set;}
    public int ergo {get; set;}
    public int fire_rate {get; set;}
    public int stability {get; set;}
    public int damage {get; set;}
    public int cap {get; set;}
}
}
