using Godot;
using System;

public class MapGenerator
{
    
}
